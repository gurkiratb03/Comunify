Delta Hacks 9 Project
Mobile app made on Flutter, which allows users to report an incident such as a wild animal, pothole, or a traffic light not working to public services so they can fix it and also notifies others in the community to be aware.
